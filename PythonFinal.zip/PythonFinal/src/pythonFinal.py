'''
Created on Dec 4, 2018

@author: ss223023
'''

from operator import ge, le, ne
import random

def get_valid_input(choices=set("hls")):
    while True:
        ui = input("Higher (H), Lower (L) or the Same (S)? ").lower()
        if ui in choices:
            return ui
        print("Not a valid choice, please try again.")

def game(rounds=80000):

    cards = range(2, 15)
    faces = {11: 'Jack', 12: 'Queen', 13: 'King', 14: 'Ace'}
    suits = ["Spades", "Hearts", "Clubs", "Diamonds"]

    comparisons = {'h': le, 'l': ge, 's': ne}

    pass_template = "Good job! The card is the {0} of {1}."
    fail_template = "Sorry, you fail. The card is the {0} of {1}."

    while True:
        card = random.choice(cards)
        suit = random.choice(suits)
        print("The first card is the {0} of {1}.".format(faces.get(card, card), suit))
        for round_ in range(rounds):
            next_card = random.choice(cards)
            next_suit = random.choice(suits)
            if comparisons[get_valid_input()](next_card, card):
                print(fail_template.format(faces.get(next_card, next_card), next_suit))
                print("Lost round", round_ + 1)
                
                break
            print(pass_template.format(faces.get(next_card, next_card), next_suit))
            card, suit = next_card, next_suit
        else:
            print("Congratulations!")
            
        repeat = input("Play again? ('yes' to continue)").lower()
        if repeat not in "yes":
            print("Goodbye.")
            break

if __name__ == "__main__":
    game()
    
    
#Code for GUI 
# next_card = random.choice(cards)
#         next_suit = random.choice(suits)
#         if next_card > card:
#             self._outputArea.delete("1.0", END)
#             self._outputArea.insert("1.0", pass_template).format(faces.get(card, card), suit)
#         else:
#             self._outputArea.insert("1.0", fail_template).format(faces.get(card,card), suit)
