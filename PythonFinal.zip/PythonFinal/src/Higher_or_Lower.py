'''
Created on Dec 4, 2018

@author: ss223023
'''

#imports all necessary modules
from tkinter import *
from operator import ge, le, ne
import random
import tkinter.messagebox
from _ast import Num

#global variables
cards = range(2, 15)
faces = {11: 'Jack', 12: 'Queen', 13: 'King', 14: 'Ace'}
suits = ["Spades", "Hearts", "Clubs", "Diamonds"]
        
comparisons = {'h': le, 'l': ge, 's': ne}

pass_template = "Good job! The card is the {0} of {1}."
fail_template = "Sorry, you fail. The card is the {0} of {1}."


num_rounds = 0
#sets up GUI
class Editor(Frame):
    def __init__(self):
        #Initializes the frame and master title
        Frame.__init__(self, bg = "black")
        self.master.title("Poker-Higher or Lower")
        self.grid()
        

        
        #Intial card selection
        card = random.choice(cards)
        suit = random.choice(suits)
        
        #first image
        img1 = PhotoImage(file = "../PNG/"+str(card) + " " + str(suit)+".png")
        img1 = img1.subsample(4,4)
        self._imgLab = Label(self, image = img1, text = "First Card", bg = "black")
        self._imgLab.image = img1
        self._imgLab.grid(row = 1, column = 0, padx = 20)
        
        #2nd image placeholder
        img2 = PhotoImage(file = "../PNG/gray_back.png")
        img2 = img2.subsample(4,4)
        self._imgLab2 = Label(self, image = img2, text = "Second Card", bg = "black")
        self._imgLab2.image = img2
        self._imgLab2.grid(row = 1, column = 3, padx = 20)
        
        #Labels
#         round_count = Label(self, text = "Round: %d" % num_rounds, fg = "blue")
#         round_count.config(height = 10, width = 10)
#         round_count.grid(row = 1, column = 4)
        
        #Command buttons
        h = Button(self, text="Higher", fg = "blue", bg = "black", command = lambda: self._higher(card, suit, cards, suits, num_rounds), anchor=CENTER)
        h.config(height=5, width=15)
        h.grid(row=3, column = 0, padx = 20)
        
        s = Button(self, text="Same", fg = "blue", bg = "black", command = lambda: self._same(card, suit, cards, suits, num_rounds), anchor=CENTER)
        s.config(height=5, width=15)
        s.grid(row=3, column = 4, padx = 20)
        
        l = Button(self, text="Lower",fg = "blue", bg = "black", command = lambda: self._lower(card, suit, cards, suits, num_rounds), anchor=CENTER)
        l.config(height=5, width=15)
        l.grid(row=3, column = 3, padx = 20)
        
        cont_Game = Button(self, text = "Continue", fg = "blue", bg = "black", command = lambda: self._contGame(card, suit, cards, suits))
        cont_Game.grid(row = 4, column = 2, sticky = E+W)
        
        q = Button(self, text = 'Quit', fg = "red", bg = "black", command = self._quit, anchor=CENTER)
        q.grid(row=4, column=0, sticky=N+S+E+W)
        
        #Creates frame for output area and scroll bar
        self._textPane = Frame(self)
        self._textPane.grid(row = 2, column = 0, columnspan = 9, sticky = N+S+E+W)
        
        self._yScroll = Scrollbar(self._textPane, orient = VERTICAL)
        self._yScroll.grid(row = 0, column = 1, sticky = N+S)
        
        self._outputArea = Text(self._textPane, width = 100, height = 10, fg = "white", bg = "black", yscrollcommand = self._yScroll.set)
        self._outputArea.grid(row = 0, column = 0, sticky = N+S+E+W)
        
        self._yScroll["command"] = self._outputArea.yview
        
        #Creates frame for round count
        self._roundCount = Frame(self)
        self._roundCount.grid(row = 1, column = 4)
        
        self._roundOutput = Text(self._roundCount, width = 20, height = 10, fg = "white", bg = "black")
        self._roundOutput.grid(row = 0, column = 0, sticky = N+S+E+W)
        
        
        
        #Displays text of first card chosen
        self._outputArea.insert("1.0", "The first card is the {0} of {1}.".format(faces.get(card, card), suit))
        self._roundOutput.insert("1.0", "Round Number\n     %d" % (num_rounds + 1))
   
            
    #Function that gives a point if next card is higher 
    def _higher(self, card, suit, cards, suits, num_rounds):
        next_card = random.choice(cards)
        next_suit = random.choice(suits)
        if next_card > card:
            self._outputArea.delete("1.0", END)
            self._outputArea.insert("1.0", pass_template.format(faces.get(next_card, next_card), next_suit))
            #tkinter.messagebox.showerror(message = pass_template.format(faces.get(next_card, next_card), next_suit), parent = self)
            Editor.inc(self, num_rounds)

            card = next_card
            suit = next_suit
            
        else:
            self._outputArea.delete("1.0", END)
            self._outputArea.insert("1.0", fail_template.format(faces.get(next_card, next_card), next_suit))
            #tkinter.messagebox.showerror(message = fail_template.format(faces.get(next_card, next_card), next_suit), parent = self)
            #tkinter.messagebox.showerror(title = "You lost" ,message = "You lost on round %d" % num_rounds)
            num_rounds = 0
        return num_rounds
        
    #Function that gives a point if next card is lower
    def _lower(self, card, suit, cards, suits, num_rounds):
        next_card = random.choice(cards)
        next_suit = random.choice(suits)
        if next_card > card:
            self._outputArea.delete("1.0", END)
            self._outputArea.insert("1.0", pass_template.format(faces.get(next_card, next_card), next_suit))
            #tkinter.messagebox.showerror(message = pass_template.format(faces.get(next_card, next_card), next_suit), parent = self)
            Editor.inc(self, num_rounds)

            card = next_card
            suit = next_suit
            
        else:
            self._outputArea.delete("1.0", END)
            self._outputArea.insert("1.0", fail_template.format(faces.get(next_card, next_card), next_suit))
            #tkinter.messagebox.showerror(message = fail_template.format(faces.get(next_card, next_card), next_suit), parent = self)
            #tkinter.messagebox.showerror(title = "You lost" ,message = "You lost on round %d" % num_rounds)
            num_rounds = 0
        return num_rounds
    #function that gives point if next card is equal
    def _same(self, card, suit, cards, suits, num_rounds):
        next_card = random.choice(cards)
        next_suit = random.choice(suits)
        if next_card > card:
            self._outputArea.delete("1.0", END)
            self._outputArea.insert("1.0", pass_template.format(faces.get(next_card, next_card), next_suit))
            #tkinter.messagebox.showerror(message = pass_template.format(faces.get(next_card, next_card), next_suit), parent = self)
            Editor.inc(self, num_rounds)

            card = next_card
            suit = next_suit
            
        else:
            self._outputArea.delete("1.0", END)
            self._outputArea.insert("1.0", fail_template.format(faces.get(next_card, next_card), next_suit))
            #tkinter.messagebox.showerror(message = fail_template.format(faces.get(next_card, next_card), next_suit), parent = self)
            #tkinter.messagebox.showerror(title = "You lost" ,message = "You lost on round %d" % num_rounds)
            num_rounds = 0
        return num_rounds
    
    #Function increments round number and updates display of round number on screen
    def inc(self, num_rounds):
        num_rounds += 1
        self._roundOutput.delete("1.0", END)
        self._roundOutput.insert("1.0", "Round Number\n     %d" % (num_rounds + 1))
    
    #function exits out of the window   
    def _quit(self):
        Editor.quit(self)
    
    #Continues the game by updating specific variables and text areas
    def _contGame(self, card, suit, cards, suits):
        self._outputArea.delete("1.0", END)
        self._outputArea.insert("1.0", "The first card is the {0} of {1}.".format(faces.get(card, card), suit))
        
        self._imgLab.destroy()
        
        img1 = PhotoImage(file = "../PNG/"+str(card) + " " + str(suit)+".png")
        img1 = img1.subsample(4,4)
        self._imgLab = Label(self, image = img1, text = "First Card")            
        self._imgLab.image = img1
        self._imgLab.grid(row = 1, column = 0, padx = 20)
        


def main():
    Editor().mainloop()
    
main()