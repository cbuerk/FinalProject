'''
Created on Dec 4, 2018

@author: ss223023
'''

#imports all necessary modules
from tkinter import *
from operator import ge, le, ne
import random
import tkinter.messagebox
from _ast import Num

#global variables
cards = range(2, 15)
faces = {11: 'Jack', 12: 'Queen', 13: 'King', 14: 'Ace'}
suits = ["Spades", "Hearts", "Clubs", "Diamonds"]
        
comparisons = {'h': le, 'l': ge, 's': ne}

pass_template = "Good job! The card is the {0} of {1}."
fail_template = "Sorry, you fail. The card is the {0} of {1}."

rounds = 80000
num_rounds = 0
#sets up GUI
class Editor(Frame):
    def __init__(self):
        #Initializes the frame and master title
        Frame.__init__(self)
        self.master.title("Poker-Higher or Lower")
        self.grid()
        

        
        #Intial card selection
        card = random.choice(cards)
        suit = random.choice(suits)
        
        #first image
        img1 = PhotoImage(file = "../PNG/"+str(card) + " " + str(suit)+".png")
        img1 = img1.subsample(4,4)
        self._imgLab = Label(self, image = img1, text = "First Card")
        self._imgLab.image = img1
        self._imgLab.grid(row = 1, column = 0, padx = 20)
        
        #2nd image placeholder
        img2 = PhotoImage(file = "../PNG/gray_back.png")
        img2 = img2.subsample(4,4)
        self._imgLab = Label(self, image = img2, text = "Second Card")
        self._imgLab.image = img2
        self._imgLab.grid(row = 1, column = 3, padx = 20)
        
        #Command buttons
        h = Button(self, text="Higher", fg = "blue", bg = "white", command = lambda: self._higher(card, suit, cards, suits), anchor=CENTER)
        h.config(height=5, width=15)
        h.grid(row=3, column = 0, padx = 20)
        
        s = Button(self, text="Same", fg = "blue", bg = "white", command = lambda: self._same(card, suit, cards, suits), anchor=CENTER)
        s.config(height=5, width=15)
        s.grid(row=3, column = 3, padx = 20)
        
        l = Button(self, text="Lower",fg = "blue", bg = "white", command = lambda: self._lower(card, suit, cards, suits), anchor=CENTER)
        l.config(height=5, width=15)
        l.grid(row=3, column = 4, padx = 20)
        
        q = Button(self, text = 'Quit', fg = "red", bg = "white", command = self._quit, anchor=CENTER)
        q.grid(row=4, column=0, sticky=N+S+E+W)
        
        #Creates frame for output area and scroll bar
        self._textPane = Frame(self)
        self._textPane.grid(row = 2, column = 0, columnspan = 9, sticky = N+S+E+W)
        
        self._yScroll = Scrollbar(self._textPane, orient = VERTICAL)
        self._yScroll.grid(row = 0, column = 1, sticky = N+S)
        
        self._outputArea = Text(self._textPane, width = 80, height = 20, yscrollcommand = self._yScroll.set)
        self._outputArea.grid(row = 0, column = 0, sticky = N+S+E+W)
        
        self._yScroll["command"] = self._outputArea.yview
        
        
        
        #Displays text of first card chosen
        self._outputArea.insert("1.0", "The first card is the {0} of {1}.".format(faces.get(card, card), suit))
        
   
            
    #Function that gives a point if next card is higher 
    def _higher(self, card, suit, cards, suits):
        next_card = random.choice(cards)
        next_suit = random.choice(suits)
        if next_card > card:
            self._outputArea.insert(END, "\n", pass_template.format(faces.get(next_card, next_card), next_suit))
            tkinter.messagebox.showerror(message = pass_template.format(faces.get(next_card, next_card), next_suit), parent = self)
            
        else:
            tkinter.messagebox.showerror(message = fail_template.format(faces.get(next_card, next_card), next_suit), parent = self)
        Editor.inc(self, num_rounds) 
        
    #Function that gives a point if next card is lower
    def _lower(self, cards, suits, card, suit):
        next_card = random.choice(cards)
        next_suit = random.choice(suits)
        if next_card < card:
            self._outputArea.insert(END, "\n", pass_template.format(faces.get(next_card, next_card), next_suit))
            tkinter.messagebox.showerror(message = pass_template.format(faces.get(next_card, next_card), next_suit), parent = self)
        else:
            tkinter.messagebox.showerror(message = fail_template.format(faces.get(next_card, next_card), next_suit), parent = self)
        Editor.inc(self, num_rounds)  
        
    #function that gives point if next card is equal
    def _same(self, card, suit, cards, suits,):
        next_card = random.choice(cards)
        next_suit = random.choice(suits)
        if next_card == card:
            self._outputArea.insert(END, "\n", pass_template.format(faces.get(next_card, next_card), next_suit))
            tkinter.messagebox.showerror(message = pass_template.format(faces.get(next_card, next_card), next_suit), parent = self)
            
        else:
            tkinter.messagebox.showerror(message = fail_template.format(faces.get(next_card, next_card), next_suit), parent = self)
        Editor.inc(self, num_rounds)  
    
    def inc(self, num_rounds):
        num_rounds += 1
        
    def _quit(self):
        global root
        Editor.quit(self)
    
    def _gameStart(self):
        ui = 'g'



def main():
    Editor().mainloop()
    
main()