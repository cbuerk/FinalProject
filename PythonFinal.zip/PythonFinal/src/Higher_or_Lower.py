'''
Created on Dec 4, 2018

@author: ss223023
'''
from tkinter import *
from operator import ge, le, ne
import random

#sets up GUI
class Editor(Frame):
    def __init__(self):
        #Initializes the frame and master title
        Frame.__init__(self)
        self.master.title("Poker-Higher or Lower")
        self.grid()
        
        #first image
        img1 = PhotoImage(file = "10C.png")
        img1 = img1.subsample(4,4)
        self._imgLab = Label(self, image = img1, text = "First Card")
        
        self._imgLab.image = img1
        
        self._imgLab.grid(row = 0, column = 0, padx = 20)
        
        
        
        
        #Command buttons
        h = Button(self, text="Higher", command = self._higher, anchor=CENTER)
        h.config(height=5, width=15)
        h.grid(row=1, column = 0, padx=20)
        
        s = Button(self, text="Same", command = self._same, anchor=CENTER)
        s.config(height=5, width=15)
        s.grid(row=1, column = 3)
        
        l = Button(self, text="Lower", command = self._lower, anchor=CENTER)
        l.config(height=5, width=15)
        l.grid(row=1, column = 4, padx=80)
        
            
        b = Button(self, text = 'TEST', command = self._callback, anchor=CENTER)
        b.grid(row=8, column=2, sticky=N+S+E+W)
        
        q = Button(self, text = 'Quit', command = self._quit, anchor=CENTER)
        q.grid(row=9, column=2, sticky=N+S+E+W)
        
        #Frame for text output and scrollbar
        self._textPane = Frame(self)
        self._textPane.grid(row = 8, column = 0, columnspan = 4, sticky = N+S+E+W)
        
        self._yScroll = Scrollbar(self._textPane, orient = VERTICAL)
        self._yScroll.grid(row = 0, column = 1, sticky = N+S)
        
        self._outputArea = Text(self._textPane, width = 20, height = 10, yscrollcommand = self._yScroll.set)
        self._outputArea.grid(row = 0, column = 0, sticky = N+S+E+W)
        
        cards = range(2, 15)
        faces = {11: 'Jack', 12: 'Queen', 13: 'King', 14: 'Ace'}
        suits = ["Spades", "Hearts", "Clubs", "Diamonds"]
        
        comparisons = {'h': le, 'l': ge, 's': ne}

        pass_template = "Good job! The card is the {0} of {1}."
        fail_template = "Sorry, you fail. The card is the {0} of {1}."
        
        while True:
            card = random.choice(cards)
            suit = random.choice(suits)
            

    def _callback(self):
        print('Click!')    
        
    def _higher(self):
        ui = 'h'
        
        return ui
        
    def _lower(self):
        ui = 'l'
        return ui
        
    def _same(self):
        ui = 's'
        return ui
    
    def _quit(self):
        global root
        Editor.quit(self)
    
    def _gameStart(self):
        ui = 'g'



def main():
    Editor().mainloop()
    
main()